<!DOCTYPE html>
<html>
  <head>
    <title>Payment completed</title>
  </head>
  <body>
    <h1>Payment completed!</h1>
    <a href="cart.php">Back to cart</a>
  </body>
</html>