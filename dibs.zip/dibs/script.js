
document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const paymentId = urlParams.get('paymentId');
    if (paymentId) {
      const checkoutOptions = {
        checkoutKey: 'test-checkout-key-70f6a250e545402096d871220ec7c1c7', // Replace!
        paymentId: paymentId,
        containerId: "checkout-container-div",
      };
      const checkout = new Dibs.Checkout(checkoutOptions);
      checkout.on('payment-completed', function (response) {
        window.location = 'completed.php';
      });
    } else {
      console.log("Expected a paymentId");   // No paymentId provided, 
      window.location = 'cart.php';         // go back to cart.html
    }
  });